<?php
echo '<div class="row">
            <div class="col-xs-12 col-sm-2 col-sm-offset-2 text-center">
              <a href="#" class="blzLogo">
              </a>
            </div>
            <div class="col-xs-12 col-sm-6">
              <div class="row">
                <div class="col-xs-12">
                  <ul class="list-inline keyIntro">
                    <li><a href="#">BATTLE.NET.EULA</a></li>
                    <span>|</span>
                    <li><a href="#">隐私</a></li>
                    <span>|</span>
                    <li><a href="#">法律条款</a></li>
                    <span>|</span>
                    <li><a href="#">著作权侵权</a></li>
                  </ul>
                </div>
                <div class="col-xs-12">
                  <ul class="list-inline keyIntro">
                    <li><a href="#">沪网文[2014]0731-161号</a></li>
                    <span>|</span>
                    <li><a href="#">增值电信业务经营许可证编号：沪B2-20080012</a></li>
                  </ul>
                </div>
                <div class="col-xs-12">
                  <ul class="list-inline keyIntro">
                    <li><a href="#">互联网违法和不良信息举报电话：0571-28090163</a></li>
                    <span>|</span>
                    <li><a href="#">沪公安安备：31011502002167</a></li>
                  </ul>
                </div>
                <div class="col-xs-12">
                  <p>&copy;2016 BLIZZARD ENTERTAINMENT,INC.</p>
                </div>
                <div class="col-xs-12 imgIntro">
                  <a href="#">
                    <img src="image/nav/police.png" alt=""/>
                  </a>
                  <a href="#">
                    <img src="image/nav/Fzx110.png" alt=""/>
                  </a>
                  <a href="#">
                    <img src="image/nav/Fsgs-icon.png" alt=""/>
                  </a>
                  <a href="#">
                    <img src="image/nav/Ficon20120516.png" alt=""/>
                  </a>
                </div>
              </div>
            </div>
          </div>';